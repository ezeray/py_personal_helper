from .structs.Result import Result
from .structs.MonadicListOfResult import MonadicListOfResult
from .structs.MonadicList import MonadicList
