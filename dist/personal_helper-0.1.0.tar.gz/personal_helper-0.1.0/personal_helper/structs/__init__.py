from .Result import Result
from .MonadicListOfResult import MonadicListOfResult
