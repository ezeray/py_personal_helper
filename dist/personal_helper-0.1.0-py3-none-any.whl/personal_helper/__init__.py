from .structs.Result import Result
from .structs.MonadicListOfResult import MonadicListOfResult
