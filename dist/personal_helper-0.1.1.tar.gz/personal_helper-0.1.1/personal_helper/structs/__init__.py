from .Result import Result
from .MonadicListOfResult import MonadicListOfResult
from .MonadicList import MonadicList
